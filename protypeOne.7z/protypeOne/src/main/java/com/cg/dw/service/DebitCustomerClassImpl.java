package com.cg.dw.service;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.persistence.EntityTransaction;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dw.dao.AccountDao;
import com.cg.dw.dao.CaseIdDao;
import com.cg.dw.dao.DebitCardDao;
import com.cg.dw.dao.DebitCardTransactionDao;
import com.cg.dw.exception.ErrorMessages;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.AccountBean;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.model.CustomerBean;
import com.cg.dw.model.DebitCardBean;
import com.cg.dw.model.DebitCardTransaction;

import ch.qos.logback.classic.Logger;

@Service
public class DebitCustomerClassImpl implements DebitCustomer {
	@Autowired
	private CaseIdDao caseIdDao;
	@Autowired
	private DebitCardTransactionDao debitCardTransactionDao;
	@Autowired
	private DebitCardDao debitCardDao;
	@Autowired
	private AccountDao accountDao;

	// private static Logger logger =
	// Logger.getLogger(CreditCustomerClassImpl.class);

	@Override
	public List<DebitCardBean> viewAllDebitCards() throws IBSException {

		List<DebitCardBean> list = null;
		try {
			list = debitCardDao.viewAllDebitCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return list;
	}

	Random random = new Random();
	String caseIdGenOne = " ";
	static String caseIdTotal = " ";
	static int caseIdGenTwo = 0;
	LocalDateTime timestamp;
	LocalDateTime fromDate;
	LocalDateTime toDate;
	static String setCardType = null;
	static String uniqueID = null;
	static String customerReferenceID = null;

	@Override
	public String addToServiceRequestTable(String caseIdGenOne) {
		// logger.info("entered into addToServiceRequestTable method of
		// CustomerServiceImpl class");
		Date dNow = new Date();
		SimpleDateFormat ftDateFormat = new SimpleDateFormat("yyMMddhhmmssS");
		String dateString = ftDateFormat.format(dNow);

		caseIdTotal = caseIdGenOne + dateString;

		return caseIdTotal;
	}

	@Transactional
	@Override
	public String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice, String remarks)
			throws IBSException {
		CaseIdBean caseIdObj = new CaseIdBean();
		caseIdGenOne = "RDCU";
		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setRequestMap("RDCU");
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setCardNumber(debitCardNumber);
		caseIdObj.setCustomerRemarks(remarks);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		BigInteger accountNumber = debitCardDao.getAccountNumber(debitCardNumber);

		caseIdObj.setAccountNumber(accountNumber);

		CustomerBean custom = new CustomerBean();
		custom.setUCI(accountDao.getUci(accountNumber));
		caseIdObj.setCustomerBeanObject(custom);

		caseIdObj.setDefineServiceRequest(myChoice);

		try {

			caseIdDao.actionServiceRequest(caseIdObj);

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return (customerReferenceID);
	}

	@Transactional
	@Override
	public void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException {
		try {

			debitCardDao.setNewDebitPin(debitCardNumber, pin);

		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

	}

	@Transactional
	@Override
	public String applyNewDebitCard(BigInteger accountNumber, String newCardType, String remarks) throws IBSException {
		caseIdGenOne = "ANDC";
		CaseIdBean caseIdObj = new CaseIdBean();

		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));

		caseIdObj.setDefineServiceRequest(newCardType);

		caseIdObj.setAccountNumber(accountNumber);

		caseIdObj.setCaseIdTotal(caseIdTotal);
		timestamp = LocalDateTime.now();
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setRequestMap("ANDC");
		caseIdObj.setCustomerRemarks(remarks);
		CustomerBean custom = new CustomerBean();
		custom.setUCI(accountDao.getUci(accountNumber));
		caseIdObj.setCustomerBeanObject(custom);

		caseIdObj.setCustomerReferenceId(customerReferenceID);
		try {

			caseIdDao.actionServiceRequest(caseIdObj);

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return customerReferenceID;

	}

	@Override
	public String getDebitcardType(BigInteger debitCardNumber) throws IBSException {
		String type;

		try {
			type = debitCardDao.getdebitCardType(debitCardNumber);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return type;

	}

	@Override
	@Transactional
	public void requestDebitCardLost(BigInteger debitCardNumber) throws IBSException {

		try {

			debitCardDao.blockDebitCard(debitCardNumber);

		} catch (IBSException e) {

			throw new IBSException(e.getMessage());

		}

	}

	@Transactional
	@Override
	public String raiseDebitMismatchTicket(BigInteger transactionId, String remarks) throws IBSException {
		CaseIdBean caseIdObj = new CaseIdBean();
		caseIdGenOne = "RDMT";
		BigInteger debitCardNumber = debitCardTransactionDao.getDebitCardNumber(transactionId);
		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setRequestMap("RDMT");
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setAccountNumber(debitCardDao.getDMAccountNumber(debitCardNumber));

		CustomerBean custom = new CustomerBean();
		custom.setUCI(debitCardTransactionDao.getDMUci(transactionId));
		caseIdObj.setCustomerBeanObject(custom);

		caseIdObj.setCustomerRemarks(remarks);

		caseIdObj.setCardNumber(debitCardTransactionDao.getDebitCardNumber(transactionId));

		caseIdObj.setDefineServiceRequest("Transaction ID :" + transactionId);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		try {

			caseIdDao.actionServiceRequest(caseIdObj);
			;
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return (customerReferenceID);

	}

	@Override
	public List<DebitCardTransaction> getDebitTransactions(LocalDate startDate, LocalDate endDate,
			BigInteger debitCardNumber) throws IBSException {

		List<DebitCardTransaction> debitCardBeanTrns = null;

		if (!Period.between(startDate, endDate).isNegative()) {

			try {

				debitCardBeanTrns = debitCardTransactionDao.getDebitTrans(startDate, endDate, debitCardNumber);

			} catch (IBSException e) {

				throw new IBSException(e.getMessage());
			}
		} else
			throw new IBSException(ErrorMessages.DATES_CHRONOLOGICALLY_INCORRECT);
		return debitCardBeanTrns;

	}

	@Override
	public List<DebitCardBean> getUnblockedDebitCards() throws IBSException {
		try {
			return debitCardDao.viewAllUnblockedDebitCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	@Override
	public List<AccountBean> getAccountList() throws IBSException {
		List<AccountBean> accounts = null;
		try {
			accounts = debitCardDao.getAccountList();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return accounts;
	}

	@Override
	public boolean checkDebitCardCount() throws IBSException {
		boolean check = true;
		try {
			List<DebitCardBean> debList = debitCardDao.viewAllActiveCards();
			if (debList.size() == 3)
				check = false;
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
		return check;

	}

	@Override
	@Transactional
	public void activateDebitCard(BigInteger debitCardNumber) throws IBSException {

		try {

			debitCardDao.activateDebitCard(debitCardNumber);

		} catch (IBSException e) {

			throw new IBSException(e.getMessage());

		}

	}

	@Override
	@Transactional
	public void deactivateDebitCard(BigInteger debitCardNumber) throws IBSException {

		try {

			debitCardDao.deactivateDebitCard(debitCardNumber);

		} catch (IBSException e) {

			throw new IBSException(e.getMessage());

		}

	}

	@Override
	public List<DebitCardBean> getInactiveDebitCards() throws IBSException {
		try {
			return debitCardDao.viewAllInactiveDebitCards();
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}

	@Override
	public boolean getDebitTransactions(BigInteger debitCardNumber) throws IBSException {
		boolean result = false;
		if (debitCardTransactionDao.checkTransactions(debitCardNumber)) {
			result = true;
		}
		return result;
	}

	@Override
    public DebitCardBean fetchDebitdetails(BigInteger debitCardNumber) throws IBSException {
        try {
            return debitCardDao.getDebitdetails(debitCardNumber);
        } catch (IBSException e) {
            throw new IBSException(ErrorMessages.INTERNAL_ERROR);
        }

}

	@Override
	public String getDebitcardStatus(BigInteger debitCardNumber) throws IBSException {
		String status;

		try {
			status = debitCardDao.getDebitCardStatus(debitCardNumber);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return status;

	}
}