package com.cg.dw.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dw.model.Department;
import com.cg.dw.service.DepartmentService;

@Controller
public class DepartmentController {

	@Autowired
	private DepartmentService deptService;

	@RequestMapping("/depts")
	public ModelAndView showDeptsHome() {
		return new ModelAndView("deptHomePage", "depts", deptService.findAll());
	}

	@RequestMapping("/deptMenu")
	public String showDeptsMenu() {
		return "deptMenuPage";
	}

	@RequestMapping(value = "/addNewDept", method = RequestMethod.GET)
	public String showNewDeptPage() {
		return "newDeptPage";
	}

	@RequestMapping(value = "/addNewDept", method = RequestMethod.POST)
	public ModelAndView saveDept(@ModelAttribute Department dept) {
		dept = deptService.add(dept);
		return new ModelAndView("savedDeptPage", "dept", dept);
	}

	@RequestMapping(value = "/cards", method = RequestMethod.GET)
	public String goToCards() {
		return "cardsHomePage";
	}
	
	
	

}
