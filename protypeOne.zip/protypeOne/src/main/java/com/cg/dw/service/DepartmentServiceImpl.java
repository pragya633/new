package com.cg.dw.service;

import java.math.BigInteger;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dw.dao.AccountDao;
import com.cg.dw.dao.CaseIdDao;
import com.cg.dw.dao.DebitCardDao;
import com.cg.dw.dao.DepartmentRepository;
import com.cg.dw.exception.IBSException;
import com.cg.dw.model.CaseIdBean;
import com.cg.dw.model.CustomerBean;
import com.cg.dw.model.Department;

@Service
public class DepartmentServiceImpl implements DepartmentService {

	@Autowired
	private DepartmentRepository deptRepo;
	@Autowired
	private CaseIdDao caseIdDao;
	@Autowired

	private DebitCardDao debitCardDao;
	@Autowired
	private AccountDao accountDao;
	Random random = new Random();

	@Transactional
	@Override
	public Department add(Department dept) {
		return deptRepo.add(dept);
	}

	@Transactional
	@Override
	public Department save(Department dept) {
		return deptRepo.save(dept);
	}

	@Override
	public Department findById(Long deptId) {
		return deptRepo.findById(deptId);
	}

	@Override
	public List<Department> findAll() {
		return deptRepo.findAll();
	}

	@Override
	public List<Department> findAllByName(String dName) {
		return deptRepo.findAllByName(dName);
	}

	@Transactional
	@Override
	public boolean requestDebitCardLost(BigInteger debitCardNumber) {
		boolean result = false;
		if (deptRepo.blockDebitCard(debitCardNumber)) {
			result = true;
		}
		return result;
	}

	@Transactional
	@Override
	public String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice, String remarks)
			throws IBSException {
		CaseIdBean caseIdObj = new CaseIdBean();
		String caseIdGenOne = "RDCU";
		LocalDateTime timestamp = LocalDateTime.now();
		String caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		String customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setRequestMap("RDCU");
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setCardNumber(debitCardNumber);
		caseIdObj.setCustomerRemarks(remarks);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		BigInteger accountNumber = debitCardDao.getAccountNumber(debitCardNumber);

		caseIdObj.setAccountNumber(accountNumber);

		CustomerBean custom = new CustomerBean();
		custom.setUCI(accountDao.getUci(accountNumber));
		caseIdObj.setCustomerBeanObject(custom);

		caseIdObj.setDefineServiceRequest(myChoice);

		try {

			caseIdDao.actionServiceRequest(caseIdObj);

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return (customerReferenceID);
	}

	private String addToServiceRequestTable(String caseIdGenOne) {
		Date dNow = new Date();
		SimpleDateFormat ftDateFormat = new SimpleDateFormat("yyMMddhhmmssS");
		String dateString = ftDateFormat.format(dNow);

		String caseIdTotal = caseIdGenOne + dateString;

		return caseIdTotal;
	}

}
