package com.cg.dw.service;

import java.math.BigInteger;

import com.cg.dw.exception.IBSException;

public interface DebitCustomerVerification {

	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException;

	public boolean verifyDebitCardPin(String pin) throws IBSException;

}
