package com.cg.dw.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.dw.exception.IBSException;
import com.cg.dw.model.Department;

public interface DepartmentService {
	Department add(Department dept);
	Department save(Department dept);
	Department findById(Long deptId);
	List<Department> findAll();
	List<Department> findAllByName(String dName);
	boolean requestDebitCardLost(BigInteger debitCardNumber);
	String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice, String remarks) throws IBSException;
}
